import { useEffect, useRef } from 'react';

export const useTimeTracking = () => {
  const startTime = useRef<number>(Date.now());
  const tracked = useRef(false);

  useEffect(() => {
    const trackTimeSpent = () => {
      if (!tracked.current) {
        const timeSpent = Math.round((Date.now() - startTime.current) / 1000);
        
        if (timeSpent >= 30 && typeof gtag !== 'undefined') { // Only track if user spent at least 30 seconds
          gtag('event', 'timing_complete', {
            'event_category': 'engagement',
            'name': 'page_read_time',
            'value': timeSpent
          });
          tracked.current = true;
        }
      }
    };

    // Track on page visibility change (when user switches tabs or closes)
    const handleVisibilityChange = () => {
      if (document.visibilityState === 'hidden') {
        trackTimeSpent();
      }
    };

    // Track on page unload
    const handleBeforeUnload = () => {
      trackTimeSpent();
    };

    document.addEventListener('visibilitychange', handleVisibilityChange);
    window.addEventListener('beforeunload', handleBeforeUnload);

    return () => {
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      window.removeEventListener('beforeunload', handleBeforeUnload);
    };
  }, []);
};