import { useEffect, useRef } from 'react';

export const useScrollTracking = () => {
  const turkishSectionTracked = useRef(false);

  useEffect(() => {
    const handleScroll = () => {
      const turkishSection = document.getElementById('turkish-section');
      if (turkishSection && !turkishSectionTracked.current) {
        const rect = turkishSection.getBoundingClientRect();
        const isVisible = rect.top <= window.innerHeight && rect.bottom >= 0;
        
        if (isVisible) {
          turkishSectionTracked.current = true;
          if (typeof gtag !== 'undefined') {
            gtag('event', 'scroll', {
              'event_category': 'engagement',
              'event_label': 'turkish_section_reached'
            });
          }
        }
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);
};