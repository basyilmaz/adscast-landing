import React from 'react';
import EnglishSection from './components/EnglishSection';
import TurkishSection from './components/TurkishSection';

function App() {
  return (
    <div className="min-h-screen bg-white">
      <EnglishSection />
      <TurkishSection />
    </div>
  );
}

export default App;