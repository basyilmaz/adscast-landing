import React, { useState } from 'react';
import { ArrowRight, Zap, Send, Check, AlertCircle, Menu, X, Shield, Globe, TrendingUp, Star } from 'lucide-react';

const TurkishSection: React.FC = () => {
  const [email, setEmail] = useState('');
  const [status, setStatus] = useState<'idle' | 'submitting' | 'success' | 'error'>('idle');
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const validateEmail = (email: string) => {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateEmail(email)) {
      setStatus('error');
      return;
    }

    setStatus('submitting');
    
    try {
      await new Promise(resolve => setTimeout(resolve, 1500));
      setStatus('success');
      setEmail('');
      
      // Track email signup event
      if (typeof gtag !== 'undefined') {
        gtag('event', 'signup', {
          'event_category': 'engagement',
          'event_label': 'waitlist_signup',
          'language': 'tr'
        });
      }
    } catch (error) {
      setStatus('error');
    }
  };

  const resetStatus = () => {
    if (status === 'error') {
      setStatus('idle');
    }
  };

  const navItems = [
    { name: 'Özellikler', href: '#tr-features' },
    { name: 'Fiyatlandırma', href: '#tr-pricing' },
    { name: 'İletişim', href: '#tr-contact' },
  ];

  const features = [
    {
      icon: '🌐',
      title: 'Evrensel Web Sitesi Desteği',
      description: 'WordPress, Shopify, özel siteler ve herhangi bir web platformu ile sorunsuz çalışır. Kısıtlama yok, maksimum esneklik.',
    },
    {
      icon: '🔌',
      title: 'Akıllı Entegrasyonlar',
      description: 'Native WordPress Site Kit, Shopify uygulamaları, Google API\'ları ve özel entegrasyonlar. Dakikalar içinde her şeyi bağlayın.',
    },
    {
      icon: '🤖',
      title: 'AI Otomasyon Motoru',
      description: 'Kurallarınızı bir kez ayarlayın, AI sürekli optimize etsin. Otomatik teklif yönetimi, anahtar kelime optimizasyonu ve içerik önerileri.',
    },
    {
      icon: '📊',
      title: 'Birleşik Panel',
      description: 'SEO ve Google Ads analitiği güçlü bir panelde birleştirildi. Tam performans görünümünüzü bir bakışta görün.',
    },
  ];

  const pricingTiers = [
    {
      name: 'Başlangıç',
      price: 'Ücretsiz',
      description: 'Kişisel web siteleri için mükemmel',
      features: [
        '1 Web Sitesi',
        'Temel SEO Analizi',
        'Aylık Raporlar',
        'E-posta Desteği',
      ],
    },
    {
      name: 'Pro',
      price: '$29/ay',
      description: 'Büyüyen işletmeler için',
      features: [
        '5 Web Sitesi',
        'Gelişmiş AI Optimizasyonu',
        'Google Ads Entegrasyonu',
        'Haftalık Raporlar',
        'Öncelikli Destek',
      ],
      popular: true,
    },
    {
      name: 'Ajans',
      price: '$59/ay',
      description: 'Ajanslar ve takımlar için',
      features: [
        '20 Web Sitesi',
        'Beyaz Etiket Raporları',
        'Müşteri Yönetimi',
        'API Erişimi',
        'Özel Entegrasyonlar',
      ],
    },
    {
      name: 'Kurumsal',
      price: '$129/ay',
      description: 'Büyük organizasyonlar için',
      features: [
        'Sınırsız Web Sitesi',
        'Özel Hesap Yöneticisi',
        'Özel Geliştirme',
        '7/24 Telefon Desteği',
        'SLA Garantisi',
      ],
    },
  ];

  const technologies = [
    { name: 'AI Destekli', icon: Zap, color: 'text-yellow-500' },
    { name: 'Google API\'ları', icon: Globe, color: 'text-blue-500' },
    { name: 'Kurumsal Güvenlik', icon: Shield, color: 'text-green-500' },
    { name: 'Gelişmiş Analitik', icon: TrendingUp, color: 'text-purple-500' },
  ];

  return (
    <div id="turkish-section" className="min-h-screen bg-white">
      {/* Navigation */}
      <nav className="sticky top-0 w-full z-50 bg-white/95 backdrop-blur-md border-b border-gray-200/20">
        <div className="container mx-auto px-6">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-gradient-to-r from-purple-600 to-blue-600 rounded-lg flex items-center justify-center">
                <Zap className="h-5 w-5 text-white" />
              </div>
              <span className="text-xl font-bold text-gray-900">AdsCast</span>
            </div>

            {/* Desktop Navigation */}
            <div className="hidden md:flex items-center space-x-8">
              {navItems.map((item) => (
                <a
                  key={item.name}
                  href={item.href}
                  className="text-gray-700 hover:text-purple-600 transition-colors duration-300 font-medium"
                >
                  {item.name}
                </a>
              ))}
            </div>

            {/* Language Toggle */}
            <div className="flex items-center space-x-4">
              <a
                href="#english-section"
                onClick={() => {
                  if (typeof gtag !== 'undefined') {
                    gtag('event', 'language_switch', {
                      'event_category': 'navigation',
                      'event_label': 'tr_to_en'
                    });
                  }
                }}
                className="bg-gradient-to-r from-purple-600 to-blue-600 text-white px-4 py-2 rounded-full text-sm font-medium hover:from-purple-700 hover:to-blue-700 transition-all duration-300"
              >
                🇺🇸 View in English
              </a>
              
              {/* Mobile Menu Button */}
              <button
                onClick={() => setIsMenuOpen(!isMenuOpen)}
                className="md:hidden p-2 rounded-lg hover:bg-gray-100 transition-colors duration-300"
              >
                {isMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
              </button>
            </div>
          </div>

          {/* Mobile Navigation */}
          {isMenuOpen && (
            <div className="md:hidden py-4 space-y-4 bg-white/95 backdrop-blur-md">
              {navItems.map((item) => (
                <a
                  key={item.name}
                  href={item.href}
                  onClick={() => setIsMenuOpen(false)}
                  className="block text-gray-700 hover:text-purple-600 transition-colors duration-300 font-medium py-2"
                >
                  {item.name}
                </a>
              ))}
            </div>
          )}
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative pt-20 pb-32 overflow-hidden">
        {/* Background Elements */}
        <div className="absolute inset-0 bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900" />
        <div className="absolute inset-0 bg-[url('data:image/svg+xml,%3Csvg width=%2260%22 height=%2260%22 viewBox=%220 0 60 60%22 xmlns=%22http://www.w3.org/2000/svg%22%3E%3Cg fill=%22none%22 fill-rule=%22evenodd%22%3E%3Cg fill=%22%239C92AC%22 fill-opacity=%220.1%22%3E%3Ccircle cx=%2230%22 cy=%2230%22 r=%221%22/%3E%3C/g%3E%3C/g%3E%3C/svg%3E')] opacity-20" />
        
        <div className="relative container mx-auto px-6">
          <div className="max-w-4xl mx-auto text-center">
            {/* Hero Badge */}
            <div className="inline-flex items-center space-x-2 bg-white/10 backdrop-blur-md rounded-full px-4 py-2 mb-8 animate-fade-in">
              <Zap className="h-4 w-4 text-yellow-400" />
              <span className="text-white text-sm font-medium">AI Destekli Optimizasyon Platformu</span>
            </div>

            {/* Hero Title */}
            <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold text-white mb-6 leading-tight animate-fade-in">
              Herhangi Bir Web Sitesini SEO ve Reklam Makinesine Dönüştürün
            </h1>

            {/* Hero Subtitle */}
            <p className="text-xl md:text-2xl text-blue-100 mb-12 max-w-3xl mx-auto leading-relaxed animate-fade-in">
              WordPress, Shopify ve herhangi bir web sitesi ile çalışan AI destekli SEO ve Google Ads optimizasyon platformu. Görünürlüğünüzü ve ROI'nizi otomatik olarak artırın.
            </p>

            {/* Email Capture */}
            <div className="w-full max-w-md mx-auto mb-8 animate-fade-in">
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="relative">
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => {
                      setEmail(e.target.value);
                      resetStatus();
                    }}
                    placeholder="E-posta adresinizi girin"
                    className={`w-full px-4 py-3 pr-12 rounded-xl border-2 bg-white/95 backdrop-blur-sm placeholder-gray-500 text-gray-900 transition-all duration-300 focus:outline-none ${
                      status === 'error' 
                        ? 'border-red-400 focus:border-red-500' 
                        : 'border-gray-200 focus:border-purple-400'
                    }`}
                    disabled={status === 'submitting' || status === 'success'}
                  />
                  <button
                    type="submit"
                    disabled={status === 'submitting' || status === 'success'}
                    className="absolute right-2 top-2 p-2 rounded-lg bg-gradient-to-r from-purple-600 to-blue-600 text-white hover:from-purple-700 hover:to-blue-700 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed transform hover:scale-105"
                  >
                    {status === 'submitting' && (
                      <div className="animate-spin h-5 w-5 border-2 border-white border-t-transparent rounded-full" />
                    )}
                    {status === 'success' && <Check className="h-5 w-5" />}
                    {(status === 'idle' || status === 'error') && <Send className="h-5 w-5" />}
                  </button>
                </div>

                {status === 'success' && (
                  <div className="flex items-center space-x-2 text-green-600 bg-green-50 p-3 rounded-lg animate-fade-in">
                    <Check className="h-5 w-5 flex-shrink-0" />
                    <p className="text-sm">Başarılı! Erken erişim listesine katıldınız. Yakında sizinle iletişime geçeceğiz.</p>
                  </div>
                )}

                {status === 'error' && (
                  <div className="flex items-center space-x-2 text-red-600 bg-red-50 p-3 rounded-lg animate-fade-in">
                    <AlertCircle className="h-5 w-5 flex-shrink-0" />
                    <p className="text-sm">Lütfen geçerli bir e-posta adresi girin.</p>
                  </div>
                )}

                {status === 'submitting' && (
                  <div className="text-center text-gray-600 text-sm animate-pulse">
                    Listeye ekleniyor...
                  </div>
                )}
              </form>
            </div>

            {/* Trust Signal */}
            <p className="text-blue-200 text-sm flex items-center justify-center space-x-2 animate-fade-in">
              <ArrowRight className="h-4 w-4" />
              <span>Herhangi bir web sitesi platformu ile çalışır</span>
            </p>
          </div>
        </div>

        {/* Floating Elements */}
        <div className="absolute top-20 left-10 w-20 h-20 bg-purple-400/20 rounded-full blur-xl animate-pulse" />
        <div className="absolute bottom-20 right-10 w-32 h-32 bg-blue-400/20 rounded-full blur-xl animate-pulse delay-1000" />
        <div className="absolute top-40 right-20 w-16 h-16 bg-indigo-400/20 rounded-full blur-xl animate-pulse delay-500" />
      </section>

      {/* Features Section */}
      <section id="tr-features" className="py-20 bg-gray-50">
        <div className="container mx-auto px-6">
          {/* Section Header */}
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-5xl font-bold text-gray-900 mb-4">
              Arama ve Reklam Dünyasına Hükmetmek İçin İhtiyacınız Olan Her Şey
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Herhangi bir web sitesi platformu ile çalışan güçlü AI araçları
            </p>
          </div>

          {/* Features Grid */}
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 max-w-7xl mx-auto">
            {features.map((feature, index) => (
              <div
                key={index}
                className="group bg-white rounded-2xl p-8 shadow-lg hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2 border border-gray-100 cursor-pointer"
                onClick={() => {
                  if (typeof gtag !== 'undefined') {
                    gtag('event', 'click', {
                      'event_category': 'features',
                      'event_label': `feature_card_${feature.title.toLowerCase().replace(/\s+/g, '_')}`,
                      'language': 'tr'
                    });
                  }
                }}
              >
                {/* Icon */}
                <div className="text-4xl mb-6 group-hover:scale-110 transition-transform duration-300">
                  {feature.icon}
                </div>

                {/* Title */}
                <h3 className="text-xl font-bold text-gray-900 mb-4 group-hover:text-purple-600 transition-colors duration-300">
                  {feature.title}
                </h3>

                {/* Description */}
                <p className="text-gray-600 leading-relaxed">
                  {feature.description}
                </p>

                {/* Gradient Border */}
                <div className="absolute inset-0 rounded-2xl bg-gradient-to-r from-purple-600 to-blue-600 opacity-0 group-hover:opacity-5 transition-opacity duration-300" />
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section id="tr-pricing" className="py-20 bg-white">
        <div className="container mx-auto px-6">
          {/* Section Header */}
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-5xl font-bold text-gray-900 mb-4">
              Basit, Şeffaf Fiyatlandırma
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              İhtiyaçlarınıza uygun planı seçin. İstediğiniz zaman yükselt veya düşürün.
            </p>
          </div>

          {/* Pricing Grid */}
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 max-w-7xl mx-auto">
            {pricingTiers.map((tier, index) => (
              <div
                key={index}
                className={`relative bg-white rounded-2xl p-8 border-2 transition-all duration-300 transform hover:scale-105 ${
                  tier.popular
                    ? 'border-purple-500 shadow-2xl shadow-purple-500/20'
                    : 'border-gray-200 hover:border-purple-300 shadow-lg hover:shadow-xl'
                }`}
                onMouseEnter={() => {
                  if (typeof gtag !== 'undefined') {
                    gtag('event', 'view_item', {
                      'event_category': 'pricing',
                      'event_label': `pricing_tier_${tier.name.toLowerCase()}`,
                      'language': 'tr'
                    });
                  }
                }}
              >
                {/* Popular Badge */}
                {tier.popular && (
                  <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                    <div className="bg-gradient-to-r from-purple-600 to-blue-600 text-white px-4 py-2 rounded-full text-sm font-bold flex items-center space-x-1">
                      <Star className="h-4 w-4" />
                      <span>Popüler</span>
                    </div>
                  </div>
                )}

                {/* Plan Name */}
                <h3 className="text-2xl font-bold text-gray-900 mb-2">
                  {tier.name}
                </h3>

                {/* Price */}
                <div className="mb-4">
                  <span className="text-4xl font-bold text-gray-900">
                    {tier.price}
                  </span>
                </div>

                {/* Description */}
                <p className="text-gray-600 mb-8">
                  {tier.description}
                </p>

                {/* Features List */}
                <ul className="space-y-4 mb-8">
                  {tier.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-center space-x-3">
                      <Check className="h-5 w-5 text-green-500 flex-shrink-0" />
                      <span className="text-gray-700">{feature}</span>
                    </li>
                  ))}
                </ul>

                {/* CTA Button */}
                <button
                  onClick={() => {
                    if (typeof gtag !== 'undefined') {
                      gtag('event', 'click', {
                        'event_category': 'engagement',
                        'event_label': `pricing_cta_${tier.name.toLowerCase()}`,
                        'language': 'tr'
                      });
                    }
                  }}
                  className={`w-full py-3 px-6 rounded-xl font-semibold transition-all duration-300 ${
                    tier.popular
                      ? 'bg-gradient-to-r from-purple-600 to-blue-600 text-white hover:from-purple-700 hover:to-blue-700 shadow-lg hover:shadow-xl'
                      : 'bg-gray-100 text-gray-900 hover:bg-gray-200'
                  } transform hover:scale-105`}
                >
                  Başlayın
                </button>
              </div>
            ))}
          </div>

          {/* Currency Note */}
          <div className="text-center mt-12">
            <p className="text-gray-500 text-sm">
              Fiyatlar USD cinsinden gösterilmektedir. TRY karşılığı için iletişime geçin.
            </p>
          </div>
        </div>
      </section>

      {/* Social Proof Section */}
      <section id="tr-contact" className="py-20 bg-gradient-to-br from-gray-900 via-purple-900 to-blue-900">
        <div className="container mx-auto px-6">
          {/* Section Header */}
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-5xl font-bold text-white mb-4">
              Dünya Çapında Ajanslar Tarafından Güvenilir
            </h2>
            <p className="text-xl text-blue-100 max-w-2xl mx-auto">
              WordPress, Shopify ve herhangi bir web sitesi platformu için geliştirildi
            </p>
          </div>

          {/* Technology Badges */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 max-w-4xl mx-auto">
            {technologies.map((tech, index) => (
              <div
                key={index}
                className="group bg-white/10 backdrop-blur-md rounded-xl p-6 text-center hover:bg-white/20 transition-all duration-300 transform hover:scale-105"
              >
                <tech.icon className={`h-12 w-12 mx-auto mb-4 ${tech.color} group-hover:scale-110 transition-transform duration-300`} />
                <h3 className="text-white font-semibold text-lg">
                  {tech.name}
                </h3>
              </div>
            ))}
          </div>

          {/* Stats */}
          <div className="grid md:grid-cols-3 gap-8 mt-16 max-w-4xl mx-auto">
            <div className="text-center">
              <div className="text-4xl md:text-5xl font-bold text-white mb-2">50K+</div>
              <div className="text-blue-200">Optimize Edilmiş Web Sitesi</div>
            </div>
            <div className="text-center">
              <div className="text-4xl md:text-5xl font-bold text-white mb-2">%180</div>
              <div className="text-blue-200">Ortalama ROI Artışı</div>
            </div>
            <div className="text-center">
              <div className="text-4xl md:text-5xl font-bold text-white mb-2">7/24</div>
              <div className="text-blue-200">AI İzleme</div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default TurkishSection;