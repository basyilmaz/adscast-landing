// Google Analytics gtag types
declare global {
  interface Window {
    dataLayer: any[];
    gtag: (
      command: 'config' | 'event' | 'js',
      targetId: string | Date,
      config?: {
        event_category?: string;
        event_label?: string;
        language?: string;
        value?: number;
        [key: string]: any;
      }
    ) => void;
  }
}

declare function gtag(
  command: 'config' | 'event' | 'js',
  targetId: string | Date,
  config?: {
    event_category?: string;
    event_label?: string;
    language?: string;
    value?: number;
    [key: string]: any;
  }
): void;

export {};